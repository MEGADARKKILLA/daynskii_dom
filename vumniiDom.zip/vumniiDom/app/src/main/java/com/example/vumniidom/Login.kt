package com.example.vumniidom

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val regb : Button = findViewById(R.id.regb)
        val nextb : Button = findViewById(R.id.nextb)
        val pass : EditText = findViewById(R.id.editTextNumberPassword)
        val  mail : EditText = findViewById(R.id.editTextTextEmailAddress)
        regb.setOnClickListener {
            val Intent : Intent = Intent(this, registration::class.java)
            startActivity(Intent)
        }
        nextb.setOnClickListener {
            if(pass.text.toString()==""){ //добавить проверку пароля из базы
                val toast : Toast;
                val  text="неверный пароль"
                val duration=Toast.LENGTH_LONG
                toast=Toast.makeText(applicationContext,text,duration)
                toast.show()
            }
            else if(!android.util.Patterns.EMAIL_ADDRESS.matcher(mail.text.toString()).matches()){
                val toast : Toast;
                val  text="неверный Email"
                val duration=Toast.LENGTH_LONG
                toast=Toast.makeText(applicationContext,text,duration)
                toast.show()
            }
            else{
                //реализовать проверку есть ли пинкод или нет и переходить на создание или ведение пин кода
                val sharedPreferences = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                val savedPinCode = sharedPreferences.getString("savedPinCode", "")
                if(savedPinCode!=""){

                    val Intent1:Intent = Intent(this,pinCodeready::class.java)
                    startActivity(Intent1)
                }
                else{
                    val Intent2 : Intent = Intent(this, pinCode::class.java)
                    startActivity(Intent2)
                }
            }

        }
    }
}