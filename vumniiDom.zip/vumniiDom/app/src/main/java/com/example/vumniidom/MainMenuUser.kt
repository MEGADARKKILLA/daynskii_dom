package com.example.vumniidom

class MainMenuUser {
}