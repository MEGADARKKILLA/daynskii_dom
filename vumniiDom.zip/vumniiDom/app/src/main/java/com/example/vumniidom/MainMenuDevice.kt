package com.example.vumniidom

class MainMenuDevice {
}