package com.example.vumniidom

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class registration : AppCompatActivity() {
    private lateinit var enter: Button
    private lateinit var usernamereg: EditText
    private lateinit var mailreg: EditText
    private lateinit var passreg: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        enter = findViewById(R.id.enter)
        usernamereg = findViewById(R.id.usernamereg)
        mailreg = findViewById(R.id.mailreg)
        passreg = findViewById(R.id.passreg)
        val reg : Button=findViewById(R.id.btn_reg)
        reg.setOnClickListener{
            if(passreg.text.toString()==""){ //добавить проверку пароля из базы
                val toast : Toast;
                val  text="неверный пароль"
                val duration=Toast.LENGTH_LONG
                toast=Toast.makeText(applicationContext,text,duration)
                toast.show()
            }
            else if(!android.util.Patterns.EMAIL_ADDRESS.matcher(mailreg.text.toString()).matches()){
                val toast : Toast;
                val  text="неверный Email"
                val duration=Toast.LENGTH_LONG
                toast=Toast.makeText(applicationContext,text,duration)
                toast.show()
            }
            else if(usernamereg.text.toString()==""){
                val toast : Toast;
                val  text="введите имя пользователя"
                val duration=Toast.LENGTH_LONG
                toast=Toast.makeText(applicationContext,text,duration)
                toast.show()
            }
            else{
                val intent : Intent = Intent(this, MainMenu::class.java)
                /* val supabase = createSupabaseClient(supabaseUrl = "",
           supabaseKey = ""
           install(Postgrest)
                }*/
            }
        }
        enter.setOnClickListener{
            val intent1 : Intent = Intent(this, Login::class.java)
        }

    }
}